import { useParams } from "react-router-dom";
//useParams es un hook que nos permite acceder a los parámetros de las URL en los componentes funcionales. 

//www.compucoder.com/silla/10
//Yo puedo capturar ese 10 y almacenarlo. 

const Sillas = () => {
    const {id} = useParams();
    //Obtengo el valor del parámetro y lo voy a desestructurar. 
    //Y puedo trabajar con ese dato. 
    console.log(id);

  return (
    <div>
        <h2>Sección Sillas</h2>
        <p>ID del producto: {id} </p>
    </div>
  )
}

export default Sillas