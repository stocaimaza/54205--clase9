import React from 'react'

const Home = () => {
  return (
    <div>
        <h2>Este es el Home, acá podemos mostrar todo el listado de Productos</h2>
    </div>
  )
}

export default Home