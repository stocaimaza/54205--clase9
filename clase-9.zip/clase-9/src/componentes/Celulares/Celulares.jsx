import React from 'react'

const Celulares = () => {
  return (
    <div>
        <h2>Sección Celulares</h2>

    </div>
  )
}

export default Celulares