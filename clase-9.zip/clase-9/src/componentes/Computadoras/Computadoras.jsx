import React from 'react'

const Computadoras = () => {
  return (
    <div>
        <h2>Sección Computadoras</h2>
    </div>
  )
}

export default Computadoras