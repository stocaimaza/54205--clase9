/*
React Router: es una librería de enrutamiento para React.
//Nos permite navegar entre componentes sin tener que recargar la página. 

¿Cómo la utilizamos? 
1) Instalamos: npm install react-router-dom
2) Importamos en nuestra App los siguientes componentes: 
BrowserRouter, Route, Routes

BrowserRouter: envuelve todos los elementos de nuestra aplicación y habilita la navegación entre ellos. 
Routes: define las rutas de navegación. 
Route: define una ruta en específico. 





*/
import NavBar from "./componentes/NavBar/NavBar";
import Home from "./componentes/Home/Home";
import Computadoras from "./componentes/Computadoras/Computadoras";
import Celulares from "./componentes/Celulares/Celulares";
import Sillas from "./componentes/Sillas/Sillas";
import { BrowserRouter, Routes, Route } from "react-router-dom";

const App = () => {
  return (
    <div>

      <BrowserRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/computadoras" element={<Computadoras />} />
          <Route path="/celulares" element={<Celulares />} />
          <Route path="/sillas/:id" element={<Sillas />} />
          <Route path="*" element={<h2>Sitio en Construcción</h2>} />
          <Route />
        </Routes>
      </BrowserRouter>






    </div>
  )
}

export default App


{/* <h2> Enlaces </h2>
<h3> Enlaces Absolutos </h3>
<p> Me conectan con una página externa </p>
<a href="https://www.infobae.com" target='_blank'> Infobae </a>

<h3> Enlaces Relativos </h3>
<p>Me permiten conectar con páginas o secciones de mi mismo sitio web</p>
<a href=""> Home </a> <br />
<a href=""> Productos </a> */}