import { useState, useEffect } from "react"

const Simpsons = () => {
    const [personaje, setPersonaje] = useState([]);

    useEffect( () => {
        fetch("https://thesimpsonsquoteapi.glitch.me/quotes?count=15")
            .then(respuesta => respuesta.json())
            .then(data => setPersonaje(data))
            .catch(error => console.log(error))
    },[])

  return (
    <div>
        <h2>Los Simpsons</h2>
        {
            personaje.map((persona, index) => (
                <div key={index}>
                    <p> Nombre: {persona.character} </p>
                    <img src={persona.image} alt={persona.character} />
                </div>
            ))
        }
    </div>
  )
}

export default Simpsons