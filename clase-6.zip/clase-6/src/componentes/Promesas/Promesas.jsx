//Programación Sincrónica y Asincrónica. 

//La programación sincrónica ejecuta una tarea a la vez, sigue un orden secuencial. 


//La programación asincrónica ejecuta varias tareas al mismo tiempo, en orden no secuencial. 
//Para practicar podemos usar settimeOut. Recuerden que recibe dos parámetros: una función callback y un tiempo en milisegundos.
//Me permite simular el retraso de una petición a un servidor. 


// Promesas: Un objeto que representa une evento a futuro. 

//Las promesas tienen tres estados: pendiente, cumplida, rechazada. 


const Promesas = () => {
    //Programación sincrónica: 
    console.log("Tarea 1");
    console.log("Tarea 2");

    //Programación Asincrónica: 
    setTimeout( () => {
        console.log("Tarea A");
    }, 3000)

    setTimeout( () => {
        console.log("Tarea B");
    }, 1000)

    //Promesas: 

    const tusPromesas = (estado) => {
        return new Promise((resolve, reject) => {
            if(estado) {
                resolve("Promesa lograda, estoy sin deudas!!");
            } else {
                reject("Promesa rechazada, segui pagando!");
            }
        })
    }

    console.log(tusPromesas(true));

    //THEN Y CATCH: 
    //Podemos concatenar dos métodos que nos permiten ejecutar una función cuando la promesa se cumple o se rechaza. 
    //THEN se ejecuta cuando la promesa se cumple. 
    //CATCH se ejecuta cuando la promesa se rechaza. 
    //FINALLY se ejecuta siempre.

    tusPromesas(true)
        .then(respuesta => {
            console.log(" Si si, logramos conectarnos", respuesta);
        })
        .catch(error => {
            console.log(error);
        })
        .finally( () => console.log("fin del proceso"))

    
    //Ahora practicamos con un array de datos: 
    const array = ["Tinki Winki", "Lala", "Po", "Dipsy"];

    const solicitarTeletubbies = (estado) => {
        return new Promise((res, rej) => {
            if(estado) {
                res(array);
            } else {
                rej ("No hay teletubbies en la tele hoy, Andres no quiere");
            }
        })
    }

    solicitarTeletubbies(false)
        .then(respuesta => console.table(respuesta))
        .catch(error => console.error(error))
        .finally( () => console.log("fin"))




  return (
    <div>Promesas</div>
  )
}

export default Promesas